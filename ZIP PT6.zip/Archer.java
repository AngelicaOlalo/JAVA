public class Archer extends Character {
    private int arrows;

    public Archer(String name, int health, int strength, int level, int arrows ) {
        super(name, health, strength, level); //the super() must be the first statement since Character variables must be initialized before the mage's variables
        //if super() is left out, java attempts to call super with the no argument super()
        setArrows(arrows);
    }

    public int getArrows() { //getter
        return arrows;
    }

    public void setArrows(int arrows) { //setter
        if (arrows < 0) {
            System.out.println("Rejects negative amount");
        } else {
            this.arrows = arrows;
        }
    }

    @Override //Part 4
    public String attack() {
        if (arrows > 0) {
            arrows--;
            return getName() + " fires an arrow" + "\nArrows Left: " + arrows;
        } else {
            return getName() + " no arrows left " + super.attack();
        }
    }

    @Override
    public void displayInfo() { //Part 5
        super.displayInfo();
        System.out.println("Arrows: " + arrows);
    }
}
