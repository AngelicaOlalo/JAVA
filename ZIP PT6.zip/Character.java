public class Character {
    private final String name;
    private int health;
    private int strength;
    private int level;
    private static int totalCharacterCreated;
    public static final String KINGDOM_NAME = "Westeros";

    public Character() { //1st constructor
        this("Unnamed Recruit", 100, 5, 1);
    }

    public Character(String name, int health, int strength, int level) { //2nd constructor
        this.name = name;
        setHealth(health);
        setStrength(strength);
        setLevel(level);
        totalCharacterCreated++;
    }

    public Character(String name) { //3rd constructor
        this(name, 100, 5, 1);
    }

    public String getName() {
        return name;
    }

    public int getHealth() {
        return health;
    }

    public void setHealth(int health) {
        this.health = clampHealth(health);
    }

    public int getStrength() {
        return strength;
    }

    public void setStrength(int strength) {
        if (strength < 0) {
            System.out.println("Rejects negative values");
        } else {
            this.strength = strength;
        }
    }

    public int getLevel() {
        return level;
    }

    public void setLevel(int level) {
        if (level < 1) {
            System.out.println("Rejects any value below 1");
        } else if (level < this.level) {
            System.out.println("Rejects any value lower than the current level");
        } else {
            this.level = level;
        }
    }

    //Changed from private to protected, when it comes to private, Character itself can directly access the member. In protected, Charatcer and its subclasses can directly access the member. And in public, any class that has access to the object can use the member
    protected int clampHealth(int health) {
        if (health < 0) {
            return 0;
        } else if (health > 100) {
            return 100;
        } else {
            return health;
        }
    }

    public void rest(int healing) {
        if (healing > 0) {
            this.health = clampHealth(this.health + healing);
        }
    }

    public boolean isAlive() {
        return this.health > 0;
    }

    public boolean isVeteran() {
        return this.level >= 10;
    }

    public void takeDamage(int amount) {
        if (amount < 0) {
            System.out.println("Rejects negative amount");
        } else {
            this.health = clampHealth(this.health - amount);
        }
    }

    public String attack() {
        return name + " performs a basic attack!";
    }

    public void displayInfo() {
        System.out.println("\nName: " + name + "\nHealth: " + health + "\nStrength: " + strength + "\nLevel: " + level);
    }
    public static int getTotalCharacters() { //Part 8
        return totalCharacterCreated; //the counter still increase when a Warrior, Mage, and Archer is create since each subclass constructor calls super(), which super() calls the Character constructor, which the subclass does not need to touch the counter itself
    }

    public static void main(String[] args) {
        Character ch1 = new Character("Daenarys", 100, 5, 1);
        Warrior ch2 = new Warrior("Brienne", 100, 6, 10, 100);
        Mage ch3 = new Mage("Melisandre", 80, 8, 7, 100);
        Archer ch4 = new Archer("Arya", 90, 5, 3, 100);

        Character[] mems = {ch1, ch2, ch3, ch4};

        for(int i = 0; i < mems.length; i++) {
            System.out.println( mems[i].attack());
            mems[i].displayInfo();
        }
    }
}