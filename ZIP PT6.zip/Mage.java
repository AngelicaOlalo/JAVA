public class Mage extends Character {
    private int mana;

    public Mage(String name, int health, int strength, int level, int mana ) {
        super(name, health, strength, level); //the super() must be the first statement since Character variables must be initialized before the mage's variables
        //if super() is left out, java attempts to call super with the no argument super()
        setMana(mana);
    }

    public int getMana() { //getter
        return mana;
    }

    public void setMana(int mana) { //setter
        if (mana < 0) {
            System.out.println("Rejects negative amount");
        } else {
            this.mana = mana;
        }
    }

    @Override //Part 4
    public String attack() {
        if (mana > 0) {
            mana--;
            return getName() + " casts a powerful magic attack" + "\nMana left: " + mana;
        } else {
            return getName() + " no mana left " + super.attack();
        }
    }

    @Override
    public void displayInfo() { //Part 5
        super.displayInfo();
        System.out.println("Mana: " + mana);
    }
}