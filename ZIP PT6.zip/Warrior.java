public class Warrior extends Character {
    private int armor;

    public Warrior(String name, int health, int strength, int level, int armor ) {
        super(name, health, strength, level); //the super() must be the first statement since Character variables must be initialized before the mage's variables
        //if super() is left out, java attempts to call super with the no argument super()
        setArmor(armor);
    }

    public int getArmor() { //getter
        return armor;
    }

    public void setArmor(int armor) { //setter
        if (armor < 0) {
            System.out.println("Rejects negative amount");
        } else {
            this.armor = armor;
        }
    }

    @Override //Part 4
    public String attack() {
        if (armor > 0) {
            armor--;
            return getName() + " attacks and protected by " + armor;
        } else {
            return getName() + " no armor left " + super.attack();
        }
    }

    @Override //Part 5
    public void displayInfo() {
        super.displayInfo(); //call super first
        System.out.println("Armor: " + armor);
    }

    @Override //Part 7
    public void takeDamage(int amount) {
        if (amount < 0) {
            System.out.println("Rejects negative amount");
        }

        int reduceAmount = amount - armor;

        if (reduceAmount < 0 ) {
            reduceAmount = 0;
        }
        super.takeDamage(reduceAmount);
    }

    public void healthProtected(int value) {
        int safeHealth =  clampHealth(value); //clampedHealth is protected in Character since Warrior extends to Character which Warrior can directly use the protected method Clamphealth
        System.out.println("Clamped health: " + safeHealth);
    }
}
